<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta property="og:url"           content="http://ab24.flightsbook.net/" />
    <meta property="og:type"          content="ab24.news –" />
    <meta property="og:title"         content="ab24.news-" />
    <meta property="og:description"   content="ab24.news is one of the most reliable and popular local daily newspaper. We provide latest reliable local news about various categories for 24/7 days." />
    <meta property="og:image"         content="http://ab24.flightsbook.net/public/front/img/ab.png"  />
    <meta property="og:image:width" content="200"/>
    <meta property="og:image:height" content="200"/>

		<title>@yield('title')</title>
        <link rel="icon" href="{{ asset('/') }}public/front/img/ab.png" />
		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700%7CLato:300,400" rel="stylesheet"> 
		
		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="{{asset('/')}}public/front/css/bootstrap.min.css"/>

		<!-- Owl Carousel -->
		<link type="text/css" rel="stylesheet" href="{{asset('/')}}public/front/css/owl.carousel.css" />
		<link type="text/css" rel="stylesheet" href="{{asset('/')}}public/front/css/owl.theme.default.css" />
		
		<!-- Font Awesome Icon -->
		<link rel="stylesheet" href="{{asset('/')}}public/front/css/font-awesome.min.css">
 <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
		<!-- Custom stlylesheet -->
		<link type="text/css" rel="stylesheet" href="{{asset('/')}}public/front/css/style.css"/>

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
       <style>
		.top-date{
		float: right;font-weight:400;color: #343a40;font-size:15px;margin-top:-3px;
		}
		.dropdown-menu > li a:hover, .dropdown-menu > li.show {
			background:black;
			color: white;
		}
		.navbar-dark .navbar-nav .nav-link {
			color: #f8f9fa;
		}
		label{
			font-weight: bold;
		}
		.label-optional{
			font-size: 13px;
		}
		.task-menu{
			margin-top: 2px;
			position: absolute;
			background: white;
			z-index: 1;
			float: right;
			right: 0px;
			box-shadow: 0 0 1px 0px;
			display: none;

		}
		.task-btn{
			color:#428bca;
			cursor: pointer;
			margin-bottom: 0px;
			font-size: 20px;
			padding-top: 5px;
			padding-left: 7px;
			padding-right: 7px;
		}
		.task-btn:active{
			color:#428bca;
			border: 0px;
		}
		.task-icon{
			color:#428bca;
		}
		.task-label{
			color:#428bca;

		}
		.dropdown-item{
			font-size: 14px;
		}
		.action-btn{
			width: 90px;
			border-radius: 0px;
			height: 30px;
			font-size: 15px;
			padding-top: 4px;
			text-align: center;
			background: #428bca;
			color: white;
			cursor: pointer;
		}
		.action-menu{
			margin-right:60px;margin-top:5px;
		}
		::-webkit-scrollbar{
		    display: none;
		  }

       .footer-logo img:hover {
  filter:none;
}



	</style>
	<style>
	.carousel {
    margin-bottom: 0;
    
}
/* The controlsy */
.carousel-control {
	left: -12px;
    height: 40px;
	width: 40px;
    background: none repeat scroll 0 0 #222222;
    border: 4px solid #FFFFFF;
    border-radius: 23px 23px 23px 23px;
    margin-top: 60px;
}
.carousel-control.right {
	right: -12px;
}
/* The indicators */
.carousel-indicators {
	right: 50%;
	top: auto;
	bottom: -19px;
	margin-right: -19px;
}
/* The colour of the indicators */
.carousel-indicators li {
	background: #cecece;
}
.carousel-indicators .active {
background: #428bca;
}
</style>

	<script src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
	<script src="{{asset('/')}}public/front/js/bongabdo.js"></script>
	<script type="text/javascript">
	
	$(document).ready(function() {
    $('#Carousel').carousel({
        interval: 5000
    })
});

	$(document).ready(function() {
    $('.mw').carousel({
        interval: 5000
    })
});

    $(document).ready(function(){
    $('.bongabdo').bongabdo({
    	showSeason: true,
    format: "DD-MM [YY]"
    });
    });
</script>
	<!--<script src="{{asset('/')}}public/front/js/jquery.min.js"></script>-->
    </head>
    <?php
date_default_timezone_set('Asia/Dhaka');
$currentDate = date("l, F j, Y ,");
$currentDate1 = date("সময়: h:i:s মিনিট",time());

$engDATE = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'January', 'February', 'March', 'April',
    'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December', 'Saturday', 'Sunday',
    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday');
$bangDATE = array('১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', '০', 'জানুয়ারী', 'ফেব্রুয়ারী', 'মার্চ', 'এপ্রিল', 'মে',
    'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর', 'শনিবার', 'রবিবার', 'সোমবার', 'মঙ্গলবার', '
বুধবার', 'বৃহস্পতিবার', 'শুক্রবার'
);
$convertedDATE = str_replace($engDATE, $bangDATE, $currentDate);
$convertedDATE1 = str_replace($engDATE, $bangDATE, $currentDate1);

?>

<style>
    
    .search-button-responsive{
        display:none;
    }
    .custom_bg_color{
            background: #CCCCCC;
    }
 
    @media screen and (min-width: 1199px) and (max-width: 2024px) {
        .nav-logo{
            display:none;
        }
    }
    @media screen and (min-width: 768px) and (max-width: 1199px) {
        .search-button-responsive{
            display: flex;

        }
        .nav-logo{
            display:none;
        }
        .search-button-responsive > button{
            padding: 4px 8px !important;
            background-color: #B30F0F;
            color: white;
            border-color: #B30F0F;
        }
    }

    .image-betwen-icon{
        width:140%;
    }
    .custom-padding-srbtn{
        padding: 4px 25px !important;
    }
    @media screen and (min-width: 768px) and (max-width: 1199px)  {
        #header #nav-header {

            height: 102px;

        }

    }
    @media screen and (min-width: 768px) and (max-width: 2024px)  {
        .logo-betwn-icon{
            display: none !important;
        }

    }

    @media screen and (min-width: 0px) and (max-width: 766px) {
        .content-news-logo { display: none; }
        #top-header{
            display:none;
        }
        #nav-header {
            background-color:white !important;
            
        }
        .button-nav > button{
            color:black;

        }
        .image-betwen-icon{
            display: inline-block;

        }

    }
    @media screen and (min-width: 0px) and (max-width: 768px) {
        .image-betwen-icon{

            margin-left:  64%;
        }
    }
    @media screen and (min-width: 0px) and (max-width: 700px) {
        .image-betwen-icon{

            margin-left: 44%;
        }
    }
    @media screen and (min-width:0px) and (max-width: 580px) {
        .image-betwen-icon{

            margin-left: 14%;
        }
    }
    @media screen and (min-width:0px) and (max-width: 471px) {
        .image-betwen-icon{

            margin-left: 10%;
            width:120%;
        }
    }
    @media screen and (min-width:0px) and (max-width: 425px) {
        .image-betwen-icon{

            margin-left: 5%;
            width:110%;
        }
      
    }
    @media screen and (min-width:0px) and (max-width: 402px) {
        .image-betwen-icon{

    width:100%;
    margin-top: 13px;
        }
        .logo-betwn-icon{
            width:50%;
             }
    }
    @media screen and (min-width:0px) and (max-width: 320px) {
        .image-betwen-icon{
            width:80%;
        }
        .logo-betwn-icon{
            width: 44%;
            padding-top: 11px;
        }
    }
    .custom-size{
        width: 30px;
        height: 40px;
        line-height: 40px;
        margin: auto;
        display: block;
        font-size: 24px;
        cursor: pointer;
        margin: 0;

    }
    @media only screen and (max-width: 1118px) {

        .nav > li > a {

            padding: 10px 12px;
        }
    }
    @media only screen and (max-width: 980px){
        .nav > li > a {
            padding: 5px 12px;
        }
    }
</style>

<header id="" Style="margin-left: 29PX;">
    <!-- Top Header -->
    <div id="top-header" style="
    margin-top: 5px;
">
        <div class="container">
            <div class="header-links">
                <ul>

                    <li>
                        <b><?php echo "$convertedDATE";?></b>
                    </li>
                    <li><span id="date-today" style="color:black;font-weight:700;"></span></li>
                   <li>
                        <b> ,<?php echo "$convertedDATE1";?></b>
                    </li>
                </ul>
            </div>
             <div class="header-links" style="padding-left: 105px;">
          <form class="" method="GET" action="{{ route('search') }}">
                <div class="wrap">
   <div class="search">
      <input type="text" class="searchTerm" placeholder="এখানে অনুসন্ধান করুন" value="{{ isset($query) ? $query : '' }}" name="query">
      <button type="submit" class="searchButton">
        <i class="fa fa-search"></i>
     </button>
   </div>
</div>
    </form>          
         
            </div>
            <div class="header-social">
                <ul>
                    <li><a href="https://web.facebook.com/softtouchbd.net"><img src="https://img.icons8.com/color/48/000000/facebook-circled.png" style="height: 30px;width:30px;"/></a></li>
                    <li><a href="#"><img src="https://img.icons8.com/color/48/000000/twitter-circled.png" style="height: 30px;width:30px;"/></a></li>

                    <li><a href="#"><img src="https://img.icons8.com/color/48/000000/youtube-play.png" style="height: 30px;width:30px;"/></a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /Top Header -->

    <!-- Center Header -->
    <div id="center-header">
        <div class="container">
            <div class="header-logo content-news-logo">

                <center><div style="">
                    <a href="{{ route('home') }}" class="logo"><img src="{{asset('/')}}public/front/img/ab.png"
                                                                    alt=""></a>
                    
                </div></center>


            </div>
           

        </div>
    </div>
   <div id="" class="nav-header1" style="margin-bottom: 10px;">
      
            <div class="container">
            <div class="row"> 
                <div class="col-sm-12 col-md-12" style="background-color:#CCCCCC;">
                    
                    <div class="last" style="">

                    <h6 style="font-size:20px;padding-left: 13px;">সর্বশেষ:
</h6>    
                    </div>
                    <div class="" style="overflow: hidden;margin-top:9px;background-color:#CCCCCC">
                     <marquee behavior="" direction="" >
                     <div style="display: inline;color:white;"  id="districts" class="bg-dark text-light">
             @foreach($footers as $headline)          
        <li style="display: inline;padding: 10px;">
            <i class="fa fa-circle" style="color:#B30F0F;"></i>
            <span style="padding-left: 10px;"><a href="{{route('singlePost',['id'=>$headline->id])}}" style="">{{ $headline->title }}</a></span>
        </li>
            @endforeach

                      
                    </div>
                    </marquee>
                       </div>

            
                </div>
        </div>
       
    </div>
</div>
    <!-- /Center Header -->
    <!-- /Center Header -->

    <!-- Nav Header -->
    <!--mobile-->
<div id="nav-header" class="mdis1">
        <div class="container ">
            <nav id="main-nav">
                <div class="nav-logo">
                     <div class="button-nav" >
                            <button class="nav-collapse-btn" style=""><i class="fa fa-close" style="color: #ef233c;
    font-size: 25px;"></i></button>
                        </div>
                  <div class="nav-logo">
                        <a href="{{ route('home') }}" class="logo"><img src="{{asset('/')}}public/front/img/ab.png" alt="" > </a>
                    </div>
                    
                </div>
                <ul class="main-nav nav navbar-nav">
                    <li class="active"><a href="{{ route('home') }}"><i class="fa fa-home fa-lg" aria-hidden="true"></i>
                        </a></li>
                   @foreach($categories as $category)
                            <li><a href="{{route('post',['id'=>$category->id])}}">{{ $category->name }}</a></li>
                        @endforeach 
       
                     

                         @foreach($latestPosts1 as $category)
    <li class="dropdown">
        <a class="dropdown-toggle"href="#" data-toggle="dropdown" style="">{{ $category->name }}<span style="padding-left: 5px;"><i class="fa fa-arrow-down" aria-hidden="true"></i></span>
</a>
<ul class="dropdown-menu p-0" id="dropdown-background" style="">

    @foreach($latestPosts as $subcat)

                    
                        <li >
    <a class="dropdown-item" href="{{route('post',['id'=>$subcat->id])}}" style="color:black;background-color: white;">{{ $subcat->name }}
</a></li>
@endforeach
                </ul>           

                        
                    
    </li>
                        @endforeach 
                        
                     
                </ul>
                <div class="footer-widget social-widget text-center" id="mdis1">

                    <ul>
                        <li><a href="https://web.facebook.com/softtouchbd.net" class="facebook"><i
                                        class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="twitter"><i class="fa fa-twitter"></i></a></li>

                        <li><a href="#" class="youtube"><i class="fa fa-youtube"></i></a></li>

                    </ul>
                </div>
            </nav>
            <div class="button-nav">
                <button class="nav-collapse-btn"><i class="custom-size fa fa-bars"></i></button> 
                <a href="{{ route('home') }}" class="logo logo-betwn-icon ml-3" style="display:inline-block;"><img class="img-fluid image-betwen-icon mr-auto" src="{{asset('/')}}public/front/img/ab.png"
                                                                    alt=""></a>
                 
              
                <button class="search-collapse-btn"><i class="custom-size fa fa-search"></i></button>
                <div class="search-form">
                    <form method="GET" action="{{ route('search') }}">
                        <input class="input" type="text" value="{{ isset($query) ? $query : '' }}" name="query"
                               placeholder="Search">
                    </form>
                </div>
            </div>
            
        </div>
    </div>
    <!--mobile-->
    <div class="container custom_bg_color" >
            <nav id="main-nav">
                <div class="nav-logo">
                    <a href="{{ route('home') }}" class="logo"><img src="{{asset('/')}}public/front/img/ab.png"
                                                                    alt=""></a>
                    <div class="button-nav">
                        <button class="nav-collapse-btn" style="padding-left: 10px;"><i class="fa fa-close" style="color: #ef233c;
    font-size: 25px;"></i></button>
                    </div>
                </div>
                <ul class="main-nav nav navbar-nav">
                    <li class="active"><a href="{{ route('home') }}"><i class="fa fa-home fa-lg" aria-hidden="true"></i>
                        </a></li>
                   @foreach($categories as $category)
                            <li><a href="{{route('post',['id'=>$category->id])}}">{{ $category->name }}</a></li>
                        @endforeach
   
                     
<li class="dropdown">
                    <a class="dropdown-toggle" href="#" data-toggle="dropdown" style="">
                        বিবিধ<span style="padding-left: 5px;"><i class="fa fa-arrow-down" aria-hidden="true"></i></span>
                    </a>
                    <ul class="dropdown-menu p-0" id="dropdown-background" style="">

                         @foreach($latestPosts as $category)
    <li><a class="dropdown-item" href="{{route('post',['id'=>$category->id])}}" style="padding: 16px 5px;padding-bottom: 0px;color: black;background: white;">{{ $category->name }}</a></li>
                        @endforeach
</ul>
                </li>
                </ul>
                <div class="footer-widget social-widget text-center" id="mdis1">

                    <ul>
                        <li><a href="https://web.facebook.com/jaintabarta/" class="facebook"><i
                                        class="fa fa-facebook"></i></a></li>
                        <li><a href="#" class="twitter"><i class="fa fa-twitter"></i></a></li>

                        <li><a href="#" class="youtube"><i class="fa fa-youtube"></i></a></li>

                    </ul>
                </div>
                
            </nav>
          


        </div>
    <script>
        var $collapse = $('.nav-collapse-btn');
        var $search = $('.search-collapse-btn');
        var $button_nav = $('.button-nav');
        var $image_betwen_icon =('.image-betwen-icon');
        $(window).resize(function() {

            console.log(window.innerWidth);
            if (window.innerWidth <= 882){
                $collapse.addClass('pull-left');
                $search.addClass('pull-right');
                $button_nav.css("float", "none");
                
            }
            else {
                $collapse.removeClass('pull-left');
                $search.removeClass('pull-right');
                $button_nav.css("float", "right");
            }
        });

        $(document).ready(function () {
          
            var $collapse = $('.nav-collapse-btn');
            var $search = $('.search-collapse-btn');
            
            if (window.innerWidth <= 882){
                $collapse.addClass('pull-left');
                $search.addClass('pull-right');
                 $button_nav.css("float",'none');
                
            }
            else {
                $collapse.removeClass('pull-left');
                $search.removeClass('pull-right');
               
            }

        })


    </script>
    <!-- /Nav Header -->

    <script src="https://bangla.plus/scripts/bangladatetoday.min.js"></script>
<script>dateToday('date-today', 'bangla');</script>
   
</header>

<!-- SECTION -->
		<div class="section">
			<!-- CONTAINER -->
			<div class="container">
				<!-- ROW -->
				<div class="row">
					<!-- Main Column -->
					<div class="col-md-8">

						<!-- breadcrumb -->
						<ul class="article-breadcrumb">
							<li><a href="{{ route('home') }}"><i class="fa fa-home" aria-hidden="true"></i></a></li>
							<li><a href="#">
							    
							    </a></li>
							<li><a href="#">{{ $search_txt}}</a></li>
							
							
						</ul>
						<!-- /breadcrumb -->
						@if($newses->count() == 0 )
						<h4 class="article-title text-danger">404 NOt Found</h4>
						@else
						<div class="row">
					<!-- Main Column -->
					@foreach($newses as $news)
					<div class="col-md-6">
						<!-- ARTICLE POST -->
						<article class="article article-post">
							@if($news->category_id == 52)
							<div class="article-main-img">
				<video controls style="height: 200px;width: 300px;" >
 <source src="{{url('video-admin/'.$news->cover_image)}}" type="video/mp4">
Your browser does not support the audio element.
</video>
</div>
							@else
							<div class="article-main-img">
								<img src="{{asset('/')}}{{$news->cover_image}}" alt="">
							</div>
							@endif
							<div class="article-body">
								<ul class="article-info">
									<li class="article-category"><a href="#">{{ $search_txt }}</a></li>
									<li class="article-type"><i class="fa fa-file-text"></i></li>
								</ul>
								<h4 class="article-title"><a href="{{route('singlePost',['id'=>$news->category_id])}}">{{ $news->title }}</a></h4>
								
								{!!  substr(strip_tags($news->paragraph), 0, 540) !!}
							
							</div>
						</article>
						<!-- /ARTICLE POST -->
					</div>
					@endforeach
					
				</div>
				@endif	
			</div>
					<!-- /Main Column -->
					
					<!-- Aside Column -->
					<div class="col-md-4">
						<!-- Ad widget -->
						<div class="widget center-block hidden-xs">
							<img class="center-block" src="{{asset('/')}}public/front/image_750x_5e78a3d56368d.jpg" alt="" height="500px" width="350px;"> 
						</div>
						<!-- /Ad widget -->
						
			</div>
					<!-- /Aside Column -->
				</div>
				<!-- /ROW -->
			</div>
			<!-- /CONTAINER -->
		</div>
		<!-- /SECTION -->
		
		<!-- AD SECTION -->
		<div class="visible-lg visible-md">
			<img class="center-block" src="./img/ad-3.jpg" alt="">
		</div>
		<!-- /AD SECTION -->
		
		
		
		<!-- FOOTER -->
		@include('front.include.footer')

		<!-- /FOOTER -->
		
		
		
		<!-- Back to top -->
		<div id="back-to-top"></div>
		<!-- Back to top -->

		<!-- Back to top -->
		<div id="back-to-top"></div>
		<!-- Back to top -->
		<script type="text/javascript">

    $(document).ready(function(){

        $('#prod_cat_id').on('change',function(){
            //console.log("hmm its change");

            var category_id=$(this).val();
             //console.log(cat_id);
             var div=$(this).parent();


             var op=`<select class="form-control productname"  name="subcategory_id" >`;

             $.ajax({
                type:'get',
                url:'{!!URL::to('findProductName')!!}',
                data:{'id':category_id},
               success:function(data){

                  //console.log('success');

                    //console.log(data);

                    //console.log(data.length);

                   // op+='<option value="0" selected disabled>choose sub-category</option>';
                    for(var i=0;i<data.length;i++){
                    op+='<option value="'+data[i].sub_name+'">'+data[i].sub_name+'</option>';
                   }
                  // console.log(op)

                  op+= `</select>`

                 $('#subcategory').html(op);
                  // div.find('#subcategory').append(op);


               },
               error:function(){

                }

             });

        });
    });
   
</script>
<script src="https://cdn.by.wonderpush.com/sdk/1.1/wonderpush-loader.min.js" async></script>
<script>
window.WonderPush = window.WonderPush || [];
WonderPush.push(["init", {
    webKey: "43ebd260a7805bbca972d5552945dcae1860c05517352137499943b83ac0283f",
}]);
</script>
		<!-- jQuery Plugins -->
	<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0&appId=2323306957775742&autoLogAppEvents=1"></script>
 <script type="text/javascript">
$(document).ready(function () {
   //Disable cut copy paste
    /*$('body').bind('cut copy paste', function (e) {
        e.preventDefault();
    });
   
    
    $("body").on("contextmenu",function(e){
        return false;
    });*/

});
</script>
<script type="text/javascript">
	function pop() {
    var popup = document.getElementById('myPopup');
    popup.classList.toggle('show');
}
</script>
		
		<script src="{{asset('/')}}public/front/js/bootstrap.min.js"></script>
		<script src="{{asset('/')}}public/front/js/owl.carousel.min.js"></script>
		<script src="{{asset('/')}}public/front/js/main.js"></script>
		<script src="{{asset('/')}}public/front/js/bootnavbar.js"></script>
		<script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
        {!! Toastr::message() !!}

	</body>
</html>
