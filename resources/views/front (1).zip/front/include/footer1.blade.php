<footer id="footer" >

	<!-- Top Footer -->
			<div id="top-footer" class="" style="background-color:#B3B6B7;">
				<!-- CONTAINER -->
				<div class="container">
					<!-- ROW -->
					<div class="row">
						<!-- Column 1 -->
						<div class="col-sm-6 col-md-3" id="f">
								
							<ul>
								
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">শীর্ষ খবর</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">বিশ্ব সংবাদ</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">জবস</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">বিজ্ঞান ও প্রযুক্তি</a></li>
							</ul>
							
							
							
						</div>
						<div class="col-sm-6 col-md-3" id="mdis1">
								
							<ul class="text-center">
								
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">শীর্ষ খবর</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">বিশ্ব সংবাদ</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">জবস</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">বিজ্ঞান ও প্রযুক্তি</a></li>
							</ul>
							
							
							
						</div>
						<!-- /Column 1 -->
						<div class="col-sm-6 col-md-3" id="f">
							<ul>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">সারা দেশ</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">রাজনীতি</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">ব্যবসা বানিজ্য</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">জীবনযাপন</a></li>
							</ul>
							</div>
							<div class="col-sm-6 col-md-3" id="mdis1">
							<ul class="text-center">
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">সারা দেশ</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">রাজনীতি</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">ব্যবসা বানিজ্য</a></li>
								<li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">জীবনযাপন</a></li>
							</ul>
							</div>
						<div class="col-sm-6 col-md-3" id="f">
							<ul>
							 <li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">খেলা-ধুলা</a></li>
						     <li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">শিল্প ও সাহিত্য</a></li>
						     <li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">পরবাস</a></li>
						     <li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">ধর্ম ও জিবন</a></li>
							</ul>
							</div>
							<div class="col-sm-6 col-md-3" id="mdis1">
							<ul class="text-center">
							 <li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">খেলা-ধুলা</a></li>
						     <li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">শিল্প ও সাহিত্য</a></li>
						     <li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">পরবাস</a></li>
						     <li style="    padding: 15px;
    box-sizing: content-box;color: 	black;"><a href="" style="color:black;">ধর্ম ও জিবন</a></li>
							</ul>
							</div>
						
						<div class="col-sm-12 col-md-3">
						    	<div class="footer-widget1 galery-widget text-center" id="mdis1" style="margin-bottom:20px">
								
								<div class="widget-title">
									<h3 style=""><b>Subscribe To Us</b></h3>
								</div>
								<ul style="color:white;">
									<form class="form-inline">
  
  <div class="form-group mx-sm-3 mb-2">
    <label for="inputPassword2" class="sr-only">Email</label>
    <input type="email" class="form-control" id="inputPassword2" placeholder="Email" style="">
  </div>
  <button type="submit" class="btn btn-primary mb-2">Subscribe
</button>
</form>
									
								</ul>
							</div>
							<!-- footer galery -->
							<div class="footer-widget galery-widget" id="mdis4">
								<div class="widget-title">
									<h3 style=""><b>Subscribe To Us</b></h3>
								</div>
								
									<form class="form-inline">
  
  <div class="form-group mx-sm-3 mb-2">
    <label for="inputPassword2" class="sr-only">Email</label>
    <input type="email" class="form-control" id="inputPassword2" placeholder="Email" style="width: 170px">
  </div>
  <button type="submit" class="btn btn-primary mb-2">Subscribe
</button>
</form>
									
								
							</div>
							<!-- /footer galery -->
                    
				        </div>
						
					</div>
					<!-- /ROW -->
				</div>
				<!-- /CONTAINER -->
			</div>
			<!-- /Top Footer -->
			<!-- Top Footer -->
			<div id="top-footer" class="" style="background-color:#9C9F9F;">
				<!-- CONTAINER -->
				<div class="container">
					<!-- ROW -->
					<div class="row">
						<!-- Column 1 -->
						<div class="col-sm-12 col-md-4">
	<div class="footer-widget about-widget text-center" id="mdis1">
								<div class="footer-logo">
	<a href="#" class="logo"><img src="{{asset('/')}}public/front/img/logo-ol3t6tqtnvngxth3oqe5r1rnder00ua1dt7qcy4lj6.png" alt="" id="im1" style=""></a>
		<p>		<span style="color:black;"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script>  <b>BartaBd | A Concern Of Queen Park</b> - All Rights Reserved</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></span>
</p>
								</div>
							</div>
							
							<!-- footer about -->
							<div class="footer-widget about-widget" id="mdis4">
								<div class="footer-logo">
	<a href="#" class="logo"><img src="{{asset('/')}}public/front/img/logo-ol3t6tqtnvngxth3oqe5r1rnder00ua1dt7qcy4lj6.png" alt="" id="im1" style=""></a>
		<p>		<span style="color:black"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script>  <b>BartaBd | A Concern Of Queen Park</b> - All Rights Reserved</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></span>
</p>
								</div>
							</div>
							<!-- /footer about -->
							
							
							
						</div>
						<!-- /Column 1 -->
						<div class="col-md-2">
							</div>
						
						<div class="col-sm-12 col-md-5">
						    	<div class="footer-widget1 galery-widget text-center" id="mdis1">
								<div class="widget-title">
									<p style="font-size:18px;"><b>প্রধান সম্পাদক: সাইফুল ইসলাম</b></p>
								</div>
								<ul style="">
									<p style="color:black;">বার্তা ও বাণিজ্যিক কার্য়ালয়: কাকলি শপিং সেন্টার (৪র্থ তলা), জল্লারপার রোড, জিন্দাবাজার, সিলেট</p>
									<p style="color:black;">যোগাযোগ : +01707070370</p>
									<p style="color:black;">ইমেইল : jaintabarta@yahoo.com, jaintabarta@gmail.com</p>
									
								</ul>
							</div>
							<!-- footer galery -->
							<div class="footer-widget galery-widget" id="mdis4">
								<div class="widget-title">
									<h3 style="padding-left: 27px"><b>প্রধান সম্পাদক: সাইফুল ইসলাম</b></h3>
								</div>
								<ul style="">
									<p style="color:black;">বার্তা ও বাণিজ্যিক কার্য়ালয়: কাকলি শপিং সেন্টার (৪র্থ তলা), জল্লারপার রোড, জিন্দাবাজার, সিলেট</p>
									<p style="color:black;">যোগাযোগ : +01707070370</p>
									<p style="color:black;">ইমেইল : jaintabarta@yahoo.com, jaintabarta@gmail.com</p>
									
								</ul>
							</div>
							<!-- /footer galery -->
                    
				        </div>
						
					</div>
					<!-- /ROW -->
				</div>
				
			</div>
			
			
			
			<div id="bottom-footer" class="section" style="background: #4C4C4C;">
			
				<div class="container-fluid">
					
					<div class="row">
						
						<div class="col-sm-3 col-md-3">
			<div class="footer-widget social-widget text-center" id="dis" style="margin-right:55px;">
								
								<ul>
									<li><a href="https://web.facebook.com/jaintabarta/" class="facebook"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#" class="twitter"><i class="fa fa-twitter"></i></a></li>
									
									<li><a href="#" class="youtube"><i class="fa fa-youtube"></i></a></li>
									
								</ul>
							</div>
				<div class="footer-widget1 social-widget text-center" id="mdis1" >
								
								<ul>
									<li><a href="https://web.facebook.com/jaintabarta/" class="facebook"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#" class="twitter"><i class="fa fa-twitter"></i></a></li>
									
									<li><a href="#" class="youtube"><i class="fa fa-youtube"></i></a></li>
									
								</ul>
							</div>
					</div>
						<div class="col-sm-5 col-md-5">
							<ul class="footer-links">
							
								<p style="font-size:15px;">এই ওয়েবসাইটে প্রকাশিত সংবাদ,আলোকচিত্র ও ভিডিওচিত্র বিনা অনুমতিতে অন্য কোথাও প্রকাশ করা সম্পূর্ণ বেআইনি।সকল স্বত্ব Bartabd কর্তৃক সংরক্ষিত</p>
								
							</ul>
						</div>
						
						<div class="col-sm-4 col-md-4 ">
							<div class="footer-copyright text-center" id="dis" style="margin-top: 24px;margin-right: 12px;">
								<span > 
 Developed by :<a href="#" target="_blank"><b>Softtouchbd</b></a>
</span>
							</div>
							<div class="footer-copyright text-center" id="mdis1">
								<span > 
 Developed by :<a href="#" target="_blank"><b>Softtouchbd</b></a>
</span>
							</div>
						</div>
						
					</div>
					
				</div>
				
			</div>
			
		</footer>

		